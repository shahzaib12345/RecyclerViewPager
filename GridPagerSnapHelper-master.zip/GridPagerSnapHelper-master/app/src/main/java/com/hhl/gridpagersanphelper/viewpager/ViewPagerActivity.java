package com.hhl.gridpagersanphelper.viewpager;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.hhl.gridpagersanphelper.R;

public class ViewPagerActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_pager);
    }
}
