package com.hhl.gridpagersanphelper;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by hanhailong on 2017/8/20.
 */

@GlideModule
public class GlideAppModule extends AppGlideModule {
}
